import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#121015',
        justifyContent: 'center',
    },
    text: {
        fontSize: 30,
        color: 'white',
        textAlign: 'center',
        
    }
  });
  